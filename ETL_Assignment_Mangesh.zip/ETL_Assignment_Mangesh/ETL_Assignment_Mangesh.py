#!/usr/bin/env python
# coding: utf-8

# In[17]:


import sqlite3
import pandas as pd

# Connect to the SQLite database
#conn = sqlite3.connect('C:\\Users\\admin\\Downloads\\ETL Assignment v22-01 (2)\\S30 ETL Assignment.db')
conn = sqlite3.connect('S30 ETL Assignment.db')
cursor = conn.cursor()

#Solution using SQL
sql_query = '''
    SELECT c.customer_id, c.age, i.item_name, SUM(o.quantity) AS total_quantity
    FROM customers AS c
    JOIN sales AS s ON c.customer_id = s.customer_id
    Join Orders As o ON s.sales_id=o.sales_id
    JOIN items AS i ON o.item_id = i.item_id
    WHERE c.age >= 18 AND c.age <= 35 AND o.quantity IS NOT NULL
    GROUP BY c.customer_id, c.age, i.item_name
'''

# Execute the SQL query
cursor.execute(sql_query)

# Fetch all the rows returned by the query
results = cursor.fetchall()
print(results)
# Store the results in a DataFrame
df_sql = pd.DataFrame(results, columns=['Customer', 'Age', 'Item', 'Quantity'])
df_sql

# Store the results in a CSV file using semicolon as the delimiter
df_sql.to_csv('sql_output_file.csv', sep=';', index=False)

# Solution using Pandas
# Load the necessary tables into DataFrames
df_customers = pd.read_sql_query('SELECT * FROM customers', conn)
df_sales = pd.read_sql_query('SELECT * FROM sales', conn)
df_items = pd.read_sql_query('SELECT * FROM items', conn)
df_orders=pd.read_sql_query('SELECT * from orders',conn)

# Merge the tables to get the relevant data
df_merged = df_customers.merge(df_sales, on='customer_id').merge(df_orders,on='sales_id').merge(df_items, on='item_id')

# Filter the data for customers aged 18-35 and non-null quantities
df_filtered = df_merged[(df_merged['age'] >= 18) & (df_merged['age'] <= 35) & (df_merged['quantity'].notnull())]

# Group by customer, age, and item, and sum the quantities
df_pandas = df_filtered.groupby(['customer_id', 'age', 'item_name']).sum().reset_index()

# Store the results in a CSV file using semicolon as the delimiter
df_pandas.to_csv('pandas_output_file.csv', sep=';', index=False)

# Close the database connection
conn.close()

